
CapitalistCoin (CPL)

CapitalistCoin is an innovative, secure and energy efficient PoW/PoS coin. It uses a faster PoW distribution mechanism to distribute the initial coins, then after 5 weeks the coin is basically transferred to a pure PoS coin, where the generation of the coin is mainly through the PoS interests.

CapitalistCoin also adopt a variable PoS rate, which gives the highest payout at 20% the first year, then decrease 5% per year until the 4th year it reaches annual interest rate of 5%, then it will remain at this rate.

Because after 5 weeks it is basically a pure PoS coin, it does not need to be intensively mined, as the PoW payout will remain the minimum. Most coins will be generated through PoS, thus it is a coin that will save a lot of energy compared to other coins.

CapitalistCoin will have a total of 70 billion coins. Initially each block will deliver 100000 to 900000 coins randomly. The PoW payout will be halved each week (7 days). After 5 weeks, the PoW payout will be fixed at 1 coin per block.

PoS will start after at least 20 days of holding of the coins in the wallet. With PoS, the coin is more resilient to 51% attack. 

Other Specifications:
	- 30 seconds block target
	- 100000 - 900000 coins per block initially
	- PoW payout will be halved every week for the first 5 weeks
	- After 5 weeks, the PoW payout will be fixed at 1 coin per block
	- Difficulty retargets every block 
	- PoS variable interests:
		- 1st year: 20%
		- 2nd year: 15%
		- 3rd year: 10%
		- 4th and subsequent years: 5%
	- Total coins will be 70 billions
	- 4 confirmations for transaction, thus fast 2 mins confirmation for transdactions
	- 50 confirmations for minted blocks
	- 1% premine for bounties, giveaways, development, support and maintenance, new feature developments etc.

	- Ports: 12788 (connection) and 12789 (RPC)

